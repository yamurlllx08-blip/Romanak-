# راه‌اندازی روی سرور

1. یک VPS یا سرویس ابری تهیه کن.
2. Docker را نصب کن.
3. پروژه را روی سرور قرار بده.
4. `backend/.env` بساز.
5. دامنه را به IP سرور وصل کن.
6. HTTPS را با Nginx/Caddy و Let's Encrypt فعال کن.
7. `PUBLIC_WEB_URL=https://دامنه-تو` بگذار.
8. SMTP واقعی را تنظیم کن.
9. Google Cloud OAuth Web Client بساز و دامنه HTTPS را در Authorized JavaScript origins اضافه کن.
10. مقدار Client ID را هم در `.env` و هم در `web/index.html` جایگزین کن.
11. `docker compose up -d --build`
12. بعد از تست، Android WebView را به دامنه HTTPS نهایی وصل کن.

برای تولید واقعی، CORS را به دامنه مشخص محدود کن، بکاپ PostgreSQL بگیر، لاگ و مانیتورینگ فعال کن و secretها را داخل Git قرار نده.
