# Android wrapper

برای نسخه اندروید، یک پروژه Android Studio با WebView بساز و URL نهایی HTTPS رمانک را در MainActivity قرار بده. در نسخه تولید، فایل‌انتقالی (cover upload)، deep link برای verify/reset و policyهای امنیتی WebView باید پشتیبانی شوند.

این پوشه فعلاً راهنمای اتصال است؛ APK امضاشده بدون keystore و حساب توسعه‌دهنده واقعی ساخته/منتشر نشده است.
